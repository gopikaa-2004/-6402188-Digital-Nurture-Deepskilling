package cts;
import java.util.Scanner;
/*Recursion is a process where a method calls itself 
 to solve a problem by breaking it into smaller sub-problems.*/
public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double forecast(double amount, double rate, int years) {
        if (years == 0) {
            return amount; // base case
        } else {
            return (1 + rate) * forecast(amount, rate, years - 1); // recursive case
        }
    }

    // Optimized version using memoization
    public static double forecastWithMemo(double amount, double rate, int years, double[] memo) {
        if (years == 0) return amount;

        if (memo[years] != 0) return memo[years];

        memo[years] = (1 + rate) * forecastWithMemo(amount, rate, years - 1, memo);
        return memo[years];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input
        System.out.print("Enter current amount: ");
        double principal = sc.nextDouble();

        System.out.print("Enter annual growth rate (in %): ");
        double rate = sc.nextDouble() / 100;

        System.out.print("Enter number of years to forecast: ");
        int time = sc.nextInt();

        // Standard recursive forecast
        double futureValue = forecast(principal, rate, time);
        System.out.printf("\n[Recursive] Forecasted Value after %d years: ₹%.2f\n", time, futureValue);

        // Optimized with memoization
        double[] memory = new double[time + 1];
        double optimizedValue = forecastWithMemo(principal, rate, time, memory);
        System.out.printf("[Memoized] Forecasted Value after %d years: ₹%.2f\n", time, optimizedValue);

        sc.close();
    }
}
