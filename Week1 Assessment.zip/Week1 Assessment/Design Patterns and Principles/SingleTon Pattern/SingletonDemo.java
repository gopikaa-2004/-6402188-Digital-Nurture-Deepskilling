package cts;
class LogService {
    // Single object reference stored privately
    private static LogService singleLogger = null;

    // Private constructor prevents instantiation from other classes
    private LogService() {
        System.out.println("LogService instance initialized.");
    }

    // Public method to access the single instance
    public static LogService access() {
        if (singleLogger == null) {
            singleLogger = new LogService();
        }
        return singleLogger;
    }

    // Method to output log messages
    public void write(String logText) {
        System.out.println("[Record] " + logText);
    }
}

public class SingletonDemo {
    public static void main(String[] args) {
        LogService logA = LogService.access();
        logA.write("System booting up...");

        LogService logB = LogService.access();
        logB.write("Loading user modules...");

        LogService logC = LogService.access();
        logC.write("Running diagnostics...");

        LogService logD = LogService.access();
        logD.write("Shutdown sequence initiated.");

        if (logA == logB && logB == logC && logC == logD) {
            System.out.println("Same instance used throughout. Singleton works perfectly!");
        } else {
            System.out.println("Different instances found. Singleton failed!");
        }
    }
}
