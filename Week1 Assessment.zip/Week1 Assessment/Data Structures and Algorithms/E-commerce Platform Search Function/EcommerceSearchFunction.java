package cts;
/*
## Big O Notation ##
Big O notation is used to evaluate the time and space complexity of an algorithm
in relation to the input size (n). It helps determine scalability and performance.

--> Useful for understanding how an algorithm behaves as input grows.
--> Critical for selecting efficient algorithms in large-scale systems.

########
## Case Analysis ##
Best Case --> Target is at beginning (Linear) or center (Binary) ---------> (Linear → O(1)) || (Binary → O(1))
Average Case --> Target somewhere in middle -------------------------------> (Linear → O(n/2) ≈ O(n)) || (Binary → O(log n))
Worst Case --> Target at end or not found --------------------------------> (Linear → O(n)) || (Binary → O(log n))
*/

import java.util.*;

class Item {
    int id;
    String name;
    String type;

    Item(int id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    @Override
    public String toString() {
        return "Item ID: " + id + ", Name: " + name + ", Category: " + type;
    }
}

public class EcommerceSearchFunction {

    // Linear search: checks one-by-one for a match
    public static Item linearFind(List<Item> list, String keyword) {
        for (Item item : list) {
            if (item.name.equalsIgnoreCase(keyword)) {
                return item;
            }
        }
        return null;
    }

    // Binary search: works on sorted data, divides and conquers
    public static Item binaryFind(List<Item> list, String keyword) {
        int left = 0;
        int right = list.size() - 1;

        while (left <= right) {
            int middle = (left + right) / 2;
            int result = list.get(middle).name.compareToIgnoreCase(keyword);

            if (result == 0)
                return list.get(middle);
            else if (result < 0)
                left = middle + 1;
            else
                right = middle - 1;
        }
        return null;
    }

    // Sort items alphabetically by name
    public static void sortItems(List<Item> list) {
        Collections.sort(list, (a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    public static void main(String[] args) {
        List<Item> inventory = new ArrayList<>();
        inventory.add(new Item(201, "Camera", "Electronics"));
        inventory.add(new Item(202, "Notebook", "Stationery"));
        inventory.add(new Item(203, "Mouse", "Accessories"));
        inventory.add(new Item(204, "Sandals", "Footwear"));
        inventory.add(new Item(205, "Monitor", "Computers"));

        Scanner input = new Scanner(System.in);
        System.out.print("Enter item name to search: ");
        String searchKey = input.nextLine();

        // ---------------- Linear Search Section ----------------
        long linearStart = System.nanoTime();
        Item resultLinear = linearFind(inventory, searchKey);
        long linearEnd = System.nanoTime();
        long linearTime = (linearEnd - linearStart) - 1000;

        System.out.println("\n>> Linear Search Result:");
        if (resultLinear != null)
            System.out.println(resultLinear);
        else
            System.out.println("Item not found!");
        System.out.println("Linear Search Time: " + linearTime + " ns");

        // ---------------- Binary Search Section ----------------
        sortItems(inventory); // Binary search needs sorted data

        long binaryStart = System.nanoTime();
        Item resultBinary = binaryFind(inventory, searchKey);
        long binaryEnd = System.nanoTime();
        long binaryTime = (binaryEnd - binaryStart) - 1000;

        System.out.println("\n>> Binary Search Result:");
        if (resultBinary != null)
            System.out.println(resultBinary);
        else
            System.out.println("Item not found!");
        System.out.println("Binary Search Time: " + binaryTime + " ns");

        input.close();
    }
}

/*
## Final Search Strategy ##
Linear Search is good for short or unsorted product lists.
Binary Search is optimal for sorted collections — it’s fast and scalable (O(log n) vs O(n)).
*/
