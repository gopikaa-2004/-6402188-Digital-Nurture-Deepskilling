package cts;

//Interface for documents
interface Document {
 void open();
}

//Concrete Document Classes
class WordDoc implements Document {
 public void open() {
     System.out.println("Opening a Word Document...");
 }
}

class PdfDoc implements Document {
 public void open() {
     System.out.println("Opening a PDF Document...");
 }
}

class ExcelDoc implements Document {
 public void open() {
     System.out.println("Opening an Excel Document...");
 }
}

//Abstract Factory
abstract class DocumentCreator {
 public abstract Document generateDocument();
}

//Concrete Factories
class WordDocFactory extends DocumentCreator {
 public Document generateDocument() {
     return new WordDoc();
 }
}

class PdfDocFactory extends DocumentCreator {
 public Document generateDocument() {
     return new PdfDoc();
 }
}

class ExcelDocFactory extends DocumentCreator {
 public Document generateDocument() {
     return new ExcelDoc();
 }
}

//Test Class
public class FactoryMethodPatternExample {
 public static void main(String[] args) {
     // Using factory to create a Word document
     DocumentCreator wordFactory = new WordDocFactory();
     Document word = wordFactory.generateDocument();
     word.open();

     // Using factory to create a PDF document
     DocumentCreator pdfFactory = new PdfDocFactory();
     Document pdf = pdfFactory.generateDocument();
     pdf.open();

     // Using factory to create an Excel document
     DocumentCreator excelFactory = new ExcelDocFactory();
     Document excel = excelFactory.generateDocument();
     excel.open();
 }
}
